﻿using System;

namespace MapSearch
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("\n======| Bem-vindo(a) ao Sistema Geográfico MapSearch |======");
            Map google = new Map("Coords");
        }
    }
}
