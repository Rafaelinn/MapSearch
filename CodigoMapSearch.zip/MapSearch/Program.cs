﻿using System;

namespace MapSearch
{
    class Program
    {
        static void Main(string[] args)
        {
            Map google = new Map("Coords");
        }
    }
}
