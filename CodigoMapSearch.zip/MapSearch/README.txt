Desenvolvido por Rafael Durand

O programa recebe coordenadas inseridos pelo usuário,
e então gera uma página do Google Maps na coordenada.

Funciona somente com o Google Chrome.

Caso não funcione uma possível solução é na linha 43 colar
o diretório do seu chrome.exe do seu PC.